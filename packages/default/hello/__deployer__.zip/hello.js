function main(args) {
	let name = args.name || 'stranger';
	let greeting = 'Hello ' + name + '!';
	console.log(greeting);
	return {body: greeting};
}

module.exports.main = main;
